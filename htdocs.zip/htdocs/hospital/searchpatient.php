<?php
require_once "connect.php";
if(isset($_POST['search'])){
$patientnumber = mysqli_real_escape_string($link, $_REQUEST['patientnumber']);
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$roomnumber  = mysqli_real_escape_string($link, $_REQUEST['roomnumber']);
if(empty($patientnumber) && empty($roomnumber)) {
	$sql = "SELECT * FROM PATIENT WHERE PATIENT_NAME = '$name'";
	$result = mysqli_query($link, $sql);
	if(mysqli_num_rows($result) > 0) {
?>
<html>
<head>
	<link rel="stylesheet" href="dashboard.css">
</head>
<body>
	<div class="searchcontainer">
<h2>Search Results:</h2>
<table>
<tr>
  <th>Number</th>
  <th>Name</th>
  <th>Age</th>
  <th>Ward Number</th>
  <th>Address</th>
  <th>Phone</th>
</tr>
<tbody>
  <?php foreach ($result as $row) { ?>
      <tr>
	    <td><?php echo mysqli_real_escape_string($link, $row["PATIENT_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_NAME"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_AGE"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["WARD_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_ADDRESS"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_PHONE"]); ?></td>
      </tr>
    <?php } ?>
</tbody>
</table>
<ul>
   <li class="li_create">
	   <a href="dashboard.php">Return</a> to Dashboard.
   </li>
</ul>
</div>
</body>
</html>
<?php		
	}
}
elseif(empty($name) && empty($roomnumber)) {
	$sql = "SELECT * FROM PATIENT WHERE PATIENT_NUMBER = '$patientnumber'";
	$result = mysqli_query($link, $sql);
	if(mysqli_num_rows($result) > 0) {
?>
<html>
<head>
	<link rel="stylesheet" href="dashboard.css">
</head>
<body>
	<div class="searchcontainer">
<h2>Search Results:</h2>
<table>
<tr>
  <th>Number</th>
  <th>Name</th>
  <th>Age</th>
  <th>Ward Number</th>
  <th>Address</th>
  <th>Phone</th>
</tr>
<tbody>
  <?php foreach ($result as $row) { ?>
      <tr>
	    <td><?php echo mysqli_real_escape_string($link, $row["PATIENT_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_NAME"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_AGE"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["WARD_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_ADDRESS"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_PHONE"]); ?></td>
      </tr>
    <?php } ?>
</tbody>
</table>
<ul>
   <li class="li_create">
	   <a href="dashboard.php">Return</a> to Dashboard.
   </li>
</ul>
</div>
</body>
</html>
<?php
	}
}
elseif(empty($patientnumber) && empty($name)) {
	$sql = "SELECT PATIENT.PATIENT_NUMBER, PATIENT.PATIENT_NAME, PATIENT.PATIENT_AGE, PATIENT.WARD_NUMBER, PATIENT.PATIENT_ADDRESS, PATIENT.PATIENT_PHONE, ROOM.ROOM_NUMBER 
	FROM PATIENT, ROOM 
	WHERE ROOM.ROOM_NUMBER = '$roomnumber'
	AND PATIENT.PATIENT_NUMBER = ROOM.PATIENT_NUMBER";
	$result = mysqli_query($link, $sql);
?>
<html>
<head>
	<link rel="stylesheet" href="dashboard.css">
</head>
<body>
	<div class="searchcontainer">
<h2>Search Results:</h2>
<table>
<tr>
  <th>Room</th>
  <th>Number</th>
  <th>Name</th>
  <th>Age</th>
  <th>Ward Number</th>
  <th>Address</th>
  <th>Phone</th>
</tr>
<tbody>
    <?php foreach ($result as $row) { ?>
      <tr>
	  	<td><?php echo mysqli_real_escape_string($link, $row["ROOM_NUMBER"]); ?></td>
	    <td><?php echo mysqli_real_escape_string($link, $row["PATIENT_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_NAME"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_AGE"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["WARD_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_ADDRESS"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_PHONE"]); ?></td>
      </tr>
	<?php } ?>
</tbody>
</table>
<ul>
   <li class="li_create">
	   <a href="dashboard.php">Return</a> to Dashboard.
   </li>
</ul>
</div>
</body>
</html>
<?php
	}
}
?>