<?php
require_once "connect.php";
if(isset($_GET['id'])){
$patientnumber = $_GET['id'];

$sql = "UPDATE ROOM SET PATIENT_NUMBER = NULL WHERE PATIENT_NUMBER = '$patientnumber'";

if (mysqli_query($link, $sql)){
	$sql = "DELETE FROM PATIENT WHERE PATIENT_NUMBER ='$patientnumber'";
	if ($link->query($sql) === TRUE) {
		header("Refresh: 3; url=dashboard.php");
		echo "Successfully Deleted Patient. ";
	}
} 
else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
?>