<?php
require_once "connect.php";
if(isset($_POST['update'])){
$employeenumber = $_GET['id'];
$ward = mysqli_real_escape_string($link, $_REQUEST['ward']);
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);
$address = mysqli_real_escape_string($link, $_REQUEST['address']);
$phone = mysqli_real_escape_string($link, $_REQUEST['phone']);
$title = mysqli_real_escape_string($link, $_REQUEST['title']);
$specialty = mysqli_real_escape_string($link, $_REQUEST['specialty']);

mysqli_query($link, "DELETE FROM DOCTOR WHERE EMPLOYEE_NUMBER = '$employeenumber'");
mysqli_query($link, "DELETE FROM NURSE WHERE EMPLOYEE_NUMBER = '$employeenumber'");
mysqli_query($link, "DELETE FROM AA WHERE EMPLOYEE_NUMBER = '$employeenumber'");

switch($_POST['title']){
case '0':
	$sql = "UPDATE EMPLOYEE SET WARD_NUMBER = '$ward', EMPLOYEE_NAME = '$name', EMPLOYEE_EMAIL = '$email', EMPLOYEE_ADDRESS = '$address', EMPLOYEE_PHONE = '$phone', EMPLOYEE_TITLE = '$title' WHERE EMPLOYEE_NUMBER = '$employeenumber'";
	if ($link->query($sql) === TRUE) {
		mysqli_query($link, "INSERT INTO doctor (EMPLOYEE_NUMBER, DOCTOR_SPECIALTY) VALUES ('$employeenumber', '$specialty')");
		echo "Updated Doctor Successfully.";
		header("Refresh: 3; url=dashboard.php");
	}
	else {
		echo "Error: ";
}
break;
case '1':
	$sql = "UPDATE EMPLOYEE SET WARD_NUMBER = '$ward', EMPLOYEE_NAME = '$name', EMPLOYEE_EMAIL = '$email', EMPLOYEE_ADDRESS = '$address', EMPLOYEE_PHONE = '$phone', EMPLOYEE_TITLE = '$title' WHERE EMPLOYEE_NUMBER = '$employeenumber'";
	if ($link->query($sql) === TRUE) {
		mysqli_query($link, "INSERT INTO nurse (EMPLOYEE_NUMBER, NURSE_SPECIALTY) VALUES ('$employeenumber', '$specialty')");
		echo "Updated Nurse Successfully.";
		header("Refresh: 3; url=dashboard.php");
	}
	else {
		echo "Error: ";
}
break;
case '2':
	$sql = "UPDATE EMPLOYEE SET WARD_NUMBER = '$ward', EMPLOYEE_NAME = '$name', EMPLOYEE_EMAIL = '$email', EMPLOYEE_ADDRESS = '$address', EMPLOYEE_PHONE = '$phone', EMPLOYEE_TITLE = '$title' WHERE EMPLOYEE_NUMBER = '$employeenumber'";
	if ($link->query($sql) === TRUE) {
		mysqli_query($link, "INSERT INTO aa (EMPLOYEE_NUMBER, AA_SPECIALTY) VALUES ('$employeenumber', '$specialty')");
		echo "Updated AA Successfully.";
		header("Refresh: 3; url=dashboard.php");
	}
	else {
		echo "Error: ";
	}
break;
default:
	echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
?>