<?php
require_once "connect.php";
if(isset($_POST['create'])){
$ward = mysqli_real_escape_string($link, $_REQUEST['ward']);
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$age = mysqli_real_escape_string($link, $_REQUEST['age']);
$address = mysqli_real_escape_string($link, $_REQUEST['address']);
$phone = mysqli_real_escape_string($link, $_REQUEST['phone']);
$UserID = mysqli_insert_id($link);

$sql = "INSERT INTO patient (PATIENT_NUMBER, PATIENT_NAME, PATIENT_AGE, WARD_NUMBER, PATIENT_ADDRESS, PATIENT_PHONE) VALUES ('$UserID', '$name', '$age', '$ward', '$address', '$phone')";

if (mysqli_query($link, $sql)){
	header("Refresh: 3; url=dashboard.php");
	echo "Successfully created Patient admitted into Room: ";
} 
else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

$patientnumber = mysqli_insert_id($link);

switch($_POST['ward']){
case '1':
	$sql = "
	UPDATE ROOM 
	SET PATIENT_NUMBER = '$patientnumber'
	WHERE PATIENT_NUMBER IS NULL
	AND WARD_NUMBER = '$ward' LIMIT 1";
	if (mysqli_query($link, $sql)){
		$query = mysqli_query($link, "SELECT ROOM_NUMBER FROM ROOM WHERE PATIENT_NUMBER = '$patientnumber'"); 
		$row= mysqli_fetch_array($query);
		$roomnumber = $row['ROOM_NUMBER'];
		echo "'$roomnumber'";
	}
	else {
		echo "Error: " . mysqli_error($link);
}
break;
case '2':
	$sql = "
	UPDATE ROOM 
	SET PATIENT_NUMBER = '$patientnumber'
	WHERE PATIENT_NUMBER IS NULL
	AND WARD_NUMBER = '$ward' LIMIT 1";
	if (mysqli_query($link, $sql)){
		$query = mysqli_query($link, "SELECT ROOM_NUMBER FROM ROOM WHERE PATIENT_NUMBER = '$patientnumber'"); 
		$row= mysqli_fetch_array($query);
		$roomnumber = $row['ROOM_NUMBER'];
		echo "'$roomnumber'";
	}
	else {
		echo "Error: " . mysqli_error($link);
}
break;
case '3':
	$sql = "
	UPDATE ROOM 
	SET PATIENT_NUMBER = '$patientnumber'
	WHERE PATIENT_NUMBER IS NULL
	AND WARD_NUMBER = '$ward' LIMIT 1";
	if (mysqli_query($link, $sql)){
		$query = mysqli_query($link, "SELECT ROOM_NUMBER FROM ROOM WHERE PATIENT_NUMBER = '$patientnumber'"); 
		$row= mysqli_fetch_array($query);
		$roomnumber = $row['ROOM_NUMBER'];
		echo "'$roomnumber'";
	}
	else {
		echo "Error: " . mysqli_error($link);
}
break;
case '4':
	$sql = "
	UPDATE ROOM 
	SET PATIENT_NUMBER = '$patientnumber'
	WHERE PATIENT_NUMBER IS NULL
	AND WARD_NUMBER = '$ward' LIMIT 1";
	if (mysqli_query($link, $sql)){
		$query = mysqli_query($link, "SELECT ROOM_NUMBER FROM ROOM WHERE PATIENT_NUMBER = '$patientnumber'"); 
		$row= mysqli_fetch_array($query);
		$roomnumber = $row['ROOM_NUMBER'];
		echo "'$roomnumber'";
	}
	else {
		echo "Error: " . mysqli_error($link);
}
break;
default:
	echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

}
?>