<?php
require_once "connect.php";
if(isset($_POST['update'])){
$patientnumber = $_GET['id'];
$ward = mysqli_real_escape_string($link, $_REQUEST['ward']);
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$age = mysqli_real_escape_string($link, $_REQUEST['age']);
$address = mysqli_real_escape_string($link, $_REQUEST['address']);
$phone = mysqli_real_escape_string($link, $_REQUEST['phone']);
$room = mysqli_real_escape_string($link, $_REQUEST['room']);

mysqli_query($link, "UPDATE ROOM SET PATIENT_NUMBER = NULL WHERE PATIENT_NUMBER = '$patientnumber'");
mysqli_query($link, "UPDATE ROOM SET PATIENT_NUMBER = '$patientnumber' WHERE PATIENT_NUMBER IS NULL AND ROOM_NUMBER = '$room' LIMIT 1");
$sql = "UPDATE PATIENT SET WARD_NUMBER = '$ward', PATIENT_NAME = '$name', PATIENT_AGE = '$age', PATIENT_ADDRESS = '$address', PATIENT_PHONE = '$phone' WHERE PATIENT_NUMBER = '$patientnumber'";	
if (mysqli_query($link, $sql)){
	header("Refresh: 3; url=dashboard.php");
	echo "Successfully Updated Patient.";
	}
else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
?>