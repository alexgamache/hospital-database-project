<?php
require_once "connect.php";
if(isset($_GET['id'])){
$employeenumber = $_GET['id'];
$title = $_GET['title'];

switch($title){
case '0':
	$sql = "DELETE FROM DOCTOR WHERE EMPLOYEE_NUMBER = '$employeenumber'";
	if ($link->query($sql) === TRUE) {
		$sql = "DELETE FROM EMPLOYEE WHERE EMPLOYEE_NUMBER = '$employeenumber'";
		if (mysqli_query($link, $sql)){
			header("Refresh: 3; url=dashboard.php");
			echo "Successfully Deleted Doctor. ";
		}
	}
	else {
		echo "Error: ";
}
break;
case '1':
	$sql = "DELETE FROM NURSE WHERE EMPLOYEE_NUMBER = '$employeenumber'";
	if ($link->query($sql) === TRUE) {
		$sql = "DELETE FROM EMPLOYEE WHERE EMPLOYEE_NUMBER = '$employeenumber'";
		if (mysqli_query($link, $sql)){
			header("Refresh: 3; url=dashboard.php");
			echo "Successfully Deleted Nurse. ";
		}
	}
	else {
		echo "Error: ";
}
break;
case '2':
	$sql = "DELETE FROM AA WHERE EMPLOYEE_NUMBER = '$employeenumber'";
	if ($link->query($sql) === TRUE) {
		$sql = "DELETE FROM EMPLOYEE WHERE EMPLOYEE_NUMBER = '$employeenumber'";
		if (mysqli_query($link, $sql)){
			header("Refresh: 3; url=dashboard.php");
			echo "Successfully Deleted AA. ";
		}
	}
	else {
		echo "Error: ";
}
break;
default:
	echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
?>