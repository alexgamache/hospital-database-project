<?php
$user = 'root';
$pass = '';
$db = 'mydb';
$db = new mysqli('localhost', $user, $pass, $db) or die("Unable to Connect");
$link = mysqli_connect("localhost", "root", "", "mydb") or die($link);
?>