<?php
	require_once "connect.php";
	
    $sql = "SELECT *
    FROM PATIENT
	ORDER BY PATIENT_NUMBER DESC";
	$patientresult = mysqli_query($link, $sql);
	
	$sql = "SELECT *
	FROM EMPLOYEE
	ORDER BY EMPLOYEE_NUMBER DESC";
	$employeeresult = mysqli_query($link, $sql);
?>
<html>
<head>
	<link rel="stylesheet" href="dashboard.css">
	<title>Dashboard</title>
</head>
<body>
<div class="container">
<div class="recent">
<h2>Most Recent Patients</h2>
<table>
<tr>
  <th>Name</th>
  <th>Age</th>
  <th>Ward Number</th>
  <th>Address</th>
  <th>Phone</th>
  <th class="action">Action</th>
</tr>
<tbody>
<?php
	if(mysqli_num_rows($patientresult) > 0) {
		foreach ($patientresult as $row) { ?>
      <tr>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_NAME"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_AGE"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["WARD_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_ADDRESS"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["PATIENT_PHONE"]); ?></td>
		<td class="action">
		<a href="editpatient.php?id=<?php echo urlencode($row['PATIENT_NUMBER']); ?>"><img class="update" src='edit.png' /></a>
		<a href="deletepatient.php?id=<?php echo urlencode($row['PATIENT_NUMBER']); ?>" onclick="return confirm('Are you sure?');"><img class="delete" src='delete.png' /></a>
		</td>
      </tr>
    <?php } }?>
</tbody>
</table>
<ul>
   <li class="li_create">
	   <a href="createpatient.php">Create</a> a Patient.
	   <a href="searchforpatient.php">Search</a> for a Patient.
   </li>
</ul>
</div>
<div class="recent2">
<h2>Most Recent Employees</h2>
<table>
<tr>
  <th>Employee Number</th>
  <th>Ward Number</th>
  <th>Name</th>
  <th>Address</th>
  <th>Phone</th>
  <th>Email</th>
   <th class="action">Action</th>
</tr>
<tbody>
<?php
	if(mysqli_num_rows($employeeresult) > 0) {
		foreach ($employeeresult as $row) { ?>
      <tr>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["WARD_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_NAME"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_ADDRESS"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_PHONE"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_EMAIL"]); ?></td>
		<td class="action">
		<a href="editemployee.php?id=<?php echo urlencode($row['EMPLOYEE_NUMBER']); ?>"><img class="update" src='edit.png' /></a>
		<a href="deleteemployee.php?id=<?php echo urlencode($row['EMPLOYEE_NUMBER']); ?>&title=<?php echo urlencode($row['EMPLOYEE_TITLE']); ?>" onclick="return confirm('Are you sure?');"><img class="delete" src='delete.png' /></a>
		</td>
      </tr>
    <?php } }?>
</tbody>
</table>
<ul>
   <li class="li_create">
	   <a href="createemployee.php">Create</a> an Employee.
	   <a href="searchforemployee.php">Search</a> for an Employee.
   </li>
</ul>
</div>
</div>
</body>
</html>
