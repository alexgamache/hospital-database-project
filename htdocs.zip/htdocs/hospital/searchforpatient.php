<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="dashboard.css">
	<title>Search for Patient</title>
</head>
<body>
<div class="container2">
<form class="input-form" method="post" action="searchpatient.php">
	<div class="search">
		<h2>
			Search for Patient by:
		</h2>
		<div class="row">
				<label>Patient Number:</label>
					<input type="text" name="patientnumber" value="">
			</div>
			<h4>
				OR
			</h4>
			<div class="row">
				<label>Full Name:</label>
					<input type="text" name="name" value="">
			</div>
			<h4>
				OR
			</h4>
			<div class="row">
				<label>Room Number:</label>
					<input type="text" name="roomnumber" value="">
			</div>
		<button class="btn" type="submit" name="search" id="search">Search</button>
		<ul>
   <li class="li_create">
	   <a href="dashboard.php">Return</a> to Dashboard.
   </li>
</ul>
	</div>
</form>
</div>
</body>