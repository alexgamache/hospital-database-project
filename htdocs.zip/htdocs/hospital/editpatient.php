<?php
require_once "connect.php";
if(isset($_GET['id'])){
$patientnumber = $_GET['id'];
$query = mysqli_query($link, "SELECT WARD_NUMBER, PATIENT_NAME, 
PATIENT_AGE, PATIENT_ADDRESS, PATIENT_PHONE
FROM PATIENT
WHERE PATIENT_NUMBER = '$patientnumber'");
if(mysqli_num_rows($query)>=1){
    while($row = mysqli_fetch_array($query)) {
		$ward = $row['WARD_NUMBER'];
        $name = $row['PATIENT_NAME'];
        $age = $row['PATIENT_AGE'];
        $address = $row['PATIENT_ADDRESS'];
        $phone = $row['PATIENT_PHONE'];
    }
$sql = mysqli_query($link, "SELECT ROOM_NUMBER FROM ROOM
WHERE PATIENT_NUMBER = '$patientnumber'");
if(mysqli_num_rows($sql)>=1){
    while($row = mysqli_fetch_array($sql)) {
		$room = $row['ROOM_NUMBER'];
    }
}
?>
<html>
<head>
	<link rel="stylesheet" href="create.css">
	<title>Edit a Patient</title>
</head>
<body>
	<div class="container1">
	<form class="input-form" method="post" action="updatepatient.php?id=<?php echo urlencode($patientnumber); ?>">
		<h2>
			Edit a Patient
		</h2>
			<div class="div_info">
			<div class="row">
				<label>Ward:</label><br>
					<select class="ward" name="ward">
						<option value="1">1 - Emergency</option>
						<option value="2">2 - Radiology</option>
						<option value="3">3 - Cardiology</option>
						<option value="4">4 - Neurology</option>
					 </select>
			</div>
			<div class="row">
				<label>Name:</label><br>
					<input type="text" name="name" id="name" value="<?=$name?>">
			</div>
			<div class="row">	
				<label>Age:</label><br>
					<input type="number" name="age" id="age" value="<?=$age?>">
			</div>
			<div class="row">	
				<label>Address:</label><br>
					<input type="text" name="address" id="address" value="<?=$address?>">
			</div>
			<div class="row">	
				<label>Phone Number:</label><br>
					<input type="tel" name="phone" id="phone" value="<?=$phone?>">
			</div>
			<div class="row">	
				<label>Room Number:</label><br>
					<input type="text" name="room" id="room" value="<?=$room?>">
			</div>
			</div>
			<button class="btn" type="submit" name="update" id="update">Update</button>
		<ul>
		  <li class="li_create">
			<a href="dashboard.php"><strong>Return</strong></a> to Dashboard.
		  </li>
		</ul>
	</form>
	</div>
</body>
</html>
<?php
}
}
?>