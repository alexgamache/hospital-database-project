<?php
require_once "connect.php";
if(isset($_POST['create'])){
$ward = mysqli_real_escape_string($link, $_REQUEST['ward']);
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);
$address = mysqli_real_escape_string($link, $_REQUEST['address']);
$phone = mysqli_real_escape_string($link, $_REQUEST['phone']);
$title = mysqli_real_escape_string($link, $_REQUEST['title']);
$specialty = mysqli_real_escape_string($link, $_REQUEST['specialty']);

$sql = "INSERT INTO employee (WARD_NUMBER, EMPLOYEE_NAME, EMPLOYEE_EMAIL, EMPLOYEE_ADDRESS, EMPLOYEE_PHONE, EMPLOYEE_TITLE) VALUES ('$ward', '$name', '$email', '$address', '$phone', '$title')";

if (mysqli_query($link, $sql)){
	header("Refresh: 2; url=dashboard.php");
    echo "Added ";
} 
else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

$UserID = mysqli_insert_id($link);

switch($_POST['title']){
case '0':
	$sql = "INSERT INTO doctor (EMPLOYEE_NUMBER, DOCTOR_SPECIALTY) VALUES ('$UserID', '$specialty')";
	if ($link->query($sql) === TRUE) {
		echo "Doctor Successfully.";
	}
	else {
		echo "Error: ";
}
break;
case '1':
	$sql = "INSERT INTO nurse (EMPLOYEE_NUMBER, NURSE_SPECIALTY) VALUES ('$UserID', '$specialty')";
	if ($link->query($sql) === TRUE) {
		echo "Nurse Successfully.";
	}
	else {
		echo "Error: ";
}
break;
case '2':
	$sql = "INSERT INTO aa (EMPLOYEE_NUMBER, AA_SPECIALTY) VALUES ('$UserID', '$specialty')";
	if ($link->query($sql) === TRUE) {
		echo "AA Successfully.";
	}
	else {
		echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
break;
default:
	echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}
?>