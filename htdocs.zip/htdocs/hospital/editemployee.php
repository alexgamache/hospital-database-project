<?php
require_once "connect.php";
if(isset($_GET['id'])){
$employeenumber = $_GET['id'];
$query = mysqli_query($link, "SELECT WARD_NUMBER, EMPLOYEE_NAME, 
EMPLOYEE_EMAIL, EMPLOYEE_ADDRESS, EMPLOYEE_PHONE, EMPLOYEE_TITLE
FROM EMPLOYEE
WHERE EMPLOYEE_NUMBER = '$employeenumber'");
if(mysqli_num_rows($query)>=1){
    while($row = mysqli_fetch_array($query)) {
		$ward = $row['WARD_NUMBER'];
        $name = $row['EMPLOYEE_NAME'];
        $email = $row['EMPLOYEE_EMAIL'];
        $address = $row['EMPLOYEE_ADDRESS'];
        $phone = $row['EMPLOYEE_PHONE'];
		$title = $row['EMPLOYEE_TITLE'];
    }
		switch($title){
		case '0':
			$sql = mysqli_query($link, "SELECT DOCTOR_SPECIALTY FROM DOCTOR
			WHERE EMPLOYEE_NUMBER = '$employeenumber'");
			if(mysqli_num_rows($sql)>=1){
				while($row = mysqli_fetch_array($sql)) {
					$specialty = $row['DOCTOR_SPECIALTY'];
				}
			}
		break;
		case '1':
			$sql = mysqli_query($link, "SELECT NURSE_SPECIALTY FROM NURSE
			WHERE EMPLOYEE_NUMBER = '$employeenumber'");
			if(mysqli_num_rows($sql)>=1){
				while($row = mysqli_fetch_array($sql)) {
					$specialty = $row['NURSE_SPECIALTY'];
				}
			}
		break;
		case '2':
			$sql = mysqli_query($link, "SELECT AA_SPECIALTY FROM AA
			WHERE EMPLOYEE_NUMBER = '$employeenumber'");
			if(mysqli_num_rows($sql)>=1){
				while($row = mysqli_fetch_array($sql)) {
					$specialty = $row['AA_SPECIALTY'];
				}
			}
		break;
		default:
			echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
		}
}
?>
<html>
<head>
	<link rel="stylesheet" href="create.css">
	<title>Edit an Employee</title>
</head>
<body>
	<div class="container1">
	<form class="input-form" method="post" action="updateemployee.php?id=<?php echo urlencode($employeenumber); ?>" >
		<h2>
			Edit an Employee
		</h2>
			<div class="div_info2">
			<div class="row">
				<label>Ward:</label><br>
					<select class="ward" name="ward">
						<option value="1">1 - Emergency</option>
						<option value="2">2 - Radiology</option>
						<option value="3">3 - Cardiology</option>
						<option value="4">4 - Neurology</option>
					 </select>
			</div>
			<div class="row">
				<label>Name:</label><br>
					<input type="text" name="name" id="name" value="<?=$name?>">
			</div>
			<div class="row">	
				<label>Email Address:</label><br>
					<input type="email" name="email" id="email" value="<?=$email?>">
			</div>
			<div class="row">	
				<label>Address:</label><br>
					<input type="text" name="address" id="address" value="<?=$address?>">
			</div>
			<div class="row">	
				<label>Phone Number:</label><br>
					<input type="tel" name="phone" id="phone" value="<?=$phone?>">
			</div>
			<div class="row">	
				<label>Title:</label><br>
					<select name="title" id="title">
						<option name="doctor" value="0">Doctor</option>
						<option name="nurse" value="1">Nurse</option>
						<option name="aa" value="2">Administrative Assistant</option>
					 </select>
			</div>
			<div class="row">	
				<label>Specialty:</label><br>
					<input type="text" name="specialty" id="specialty" value="<?=$specialty?>">
			</div>
			</div>
			<button class="btn" type="submit" name="update" id="update">Update</button>
		<ul>
		  <li class="li_create">
			<a href="dashboard.php"><strong>Return</strong></a> to Dashboard.
		  </li>
		</ul>
	</form>
	</div>
</body>
</html>
<?php
}
?>