<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="dashboard.css">
	<title>Search for Employee</title>
</head>
<body>
<div class="container2">
<form class="input-form" method="post" action="searchemployee.php">
	<div class="search">
		<h2>
			Search for Employee by:
		</h2>
		<div class="row">
				<label>Employee Number:</label>
					<input type="text" name="employeenumber" value="">
			</div>
			<h4>
				OR
			</h4>
			<div class="row">
				<label>Full Name:</label>
					<input type="text" name="name" value="">
			</div>
			<h4>
				OR
			</h4>
			<div class="row">
				<label>Ward Number:</label>
					<input type="text" name="wardnumber" value="">
			</div>
		<button class="btn" type="submit" name="search" id="search">Search</button>
		<ul>
   <li class="li_create">
	   <a href="dashboard.php">Return</a> to Dashboard.
   </li>
</ul>
	</div>
</form>
</div>
</body>