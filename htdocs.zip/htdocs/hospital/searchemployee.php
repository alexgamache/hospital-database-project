<?php
require_once "connect.php";
if(isset($_POST['search'])){
$employeenumber = mysqli_real_escape_string($link, $_REQUEST['employeenumber']);
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$wardnumber = mysqli_real_escape_string($link, $_REQUEST['wardnumber']);
if(empty($employeenumber) && empty($wardnumber)) {
	$sql = "SELECT * FROM EMPLOYEE WHERE EMPLOYEE_NAME = '$name'";
	$result = mysqli_query($link, $sql);
	if(mysqli_num_rows($result) > 0) {
?>
<html>
<head>
	<link rel="stylesheet" href="dashboard.css">
</head>
<body>
	<div class="searchcontainer">
<h2>Search Results:</h2>
<table>
<tr>
  <th>Number</th>
  <th>Ward</th>
  <th>Name</th>
  <th>Address</th>
  <th>Phone</th>
  <th>Email</th>
  <th>Title</th>
</tr>
<tbody>
  <?php foreach ($result as $row) { ?>
      <tr>
	    <td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["WARD_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_NAME"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_ADDRESS"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_PHONE"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_EMAIL"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_TITLE"]); ?></td>
      </tr>
    <?php } ?>
</tbody>
</table>
<ul>
   <li class="li_create">
	   <a href="dashboard.php">Return</a> to Dashboard.
   </li>
</ul>
</div>
</body>
</html>
<?php		
	}
}
elseif(empty($name) && empty($wardnumber)) {
	$sql = "SELECT * FROM EMPLOYEE WHERE EMPLOYEE_NUMBER = '$employeenumber'";
	$result = mysqli_query($link, $sql);
	if(mysqli_num_rows($result) > 0) {
?>
<html>
<head>
	<link rel="stylesheet" href="dashboard.css">
</head>
<body>
	<div class="searchcontainer">
<h2>Search Results:</h2>
<table>
<tr>
  <th>Number</th>
  <th>Ward</th>
  <th>Name</th>
  <th>Address</th>
  <th>Phone</th>
  <th>Email</th>
  <th>Title</th>
</tr>
<tbody>
  <?php foreach ($result as $row) { ?>
      <tr>
	    <td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["WARD_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_NAME"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_ADDRESS"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_PHONE"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_EMAIL"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_TITLE"]); ?></td>
      </tr>
    <?php } ?>
</tbody>
</table>
<ul>
   <li class="li_create">
	   <a href="dashboard.php">Return</a> to Dashboard.
   </li>
</ul>
</div>
</body>
</html>
<?php		
	}
}
elseif(empty($employeenumber) && empty($name)) {
	$sql = "SELECT DISTINCT EMPLOYEE.EMPLOYEE_NUMBER, EMPLOYEE.WARD_NUMBER, EMPLOYEE.EMPLOYEE_NAME, 
	EMPLOYEE.EMPLOYEE_ADDRESS, EMPLOYEE.EMPLOYEE_PHONE, EMPLOYEE.EMPLOYEE_EMAIL, EMPLOYEE.EMPLOYEE_TITLE
	FROM EMPLOYEE, WARD 
	WHERE EMPLOYEE.WARD_NUMBER = '$wardnumber'";
	$result = mysqli_query($link, $sql);
	if(mysqli_num_rows($result) > 0) {
?>
<html>
<head>
	<link rel="stylesheet" href="dashboard.css">
</head>
<body>
	<div class="searchcontainer">
<h2>Search Results:</h2>
<table>
<tr>
  <th>Number</th>
  <th>Ward</th>
  <th>Name</th>
  <th>Address</th>
  <th>Phone</th>
  <th>Email</th>
  <th>Title</th>
</tr>
<tbody>
  <?php foreach ($result as $row) { ?>
      <tr>
	    <td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["WARD_NUMBER"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_NAME"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_ADDRESS"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_PHONE"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_EMAIL"]); ?></td>
		<td><?php echo mysqli_real_escape_string($link, $row["EMPLOYEE_TITLE"]); ?></td>
      </tr>
    <?php } ?>
</tbody>
</table>
<ul>
   <li class="li_create">
	   <a href="dashboard.php">Return</a> to Dashboard.
   </li>
</ul>
</div>
</body>
</html>
<?php		
	}
}
}
?>