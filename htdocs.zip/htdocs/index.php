<html>
<head>
<link rel="stylesheet" href="index.css">
<h2>Welcome to Hospital Database</h2>
</link>
</head>
<form>

<button type="button"><a href="hospital/dashboard.php">Enter Site</a></button>
</form>
</html>